# تشغيل المشروع من Android نفسه

أفضل طريقة للبناء على الهاتف هي Termux مع بيئة Linux مناسبة، ثم Buildozer.

مهم:
- لا تضع Bot Token داخل ملف عام أو تنشره.
- التوكن الذي شاركته في المحادثة أصبح مكشوفًا؛ لأمان البوت يُنصح بتغييره من BotFather ثم استخدام التوكن الجديد داخل التطبيق.
- Chat ID ليس سرًا مثل التوكن، لكن يفضل عدم نشره.

## لماذا لا أضمن "كل إصدارات Android"؟
Android قديم وحديث يستخدمان APIs وصلاحيات مختلفة. الكود هنا يختار READ_MEDIA_IMAGES على Android الحديث وREAD_EXTERNAL_STORAGE على الإصدارات الأقدم، لكن لا يمكن ضمان تشغيل APK واحد على كل إصدار Android موجود في العالم. يمكن تحديد minSdk/targetSdk واختبار الإصدارات المطلوبة.

## بناء APK من Termux

ثبت Termux من مصدر موثوق، ثم:
pkg update
pkg install python git clang make zip unzip openjdk-17

ثم:
python -m pip install --upgrade pip
pip install buildozer cython

ضع ملفات المشروع في مجلد:
cd telegram_backup_android

ثم:
buildozer android debug

بعد نجاح البناء:
ls bin

ستجد APK هناك.

## ملاحظة مهمة
Buildozer/python-for-android على الهاتف قد يكون أصعب وأبطأ من البناء على Linux/WSL2، وقد تحتاج مساحة كبيرة وذاكرة كافية.

## الأذونات
التطبيق يطلب صلاحية الصور عندما تضغط "إرسال جميع الصور". لا يحاول تجاوز صلاحيات Android.

## Telegram
استخدم BotFather لإنشاء/إدارة البوت. أدخل التوكن وChat ID داخل التطبيق.
