import os
import threading
import time
import mimetypes
import requests

from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.properties import StringProperty, NumericProperty
from kivy.uix.boxlayout import BoxLayout

# NOTE: Telegram Bot Token is intentionally NOT hard-coded here.
# Put it in the app UI. If a real token was exposed, rotate it with BotFather.
# App lock code is kept locally in this source as requested by the owner.
APP_CODE = "14721472"

KV = r"""
#:import dp kivy.metrics.dp

<LockScreen>:
    orientation: "vertical"
    padding: dp(24)
    spacing: dp(14)

    Widget:

    Label:
        text: "🔐 Telegram Backup"
        font_size: "26sp"
        size_hint_y: None
        height: dp(50)

    Label:
        text: "أدخل رمز الدخول للمتابعة"
        font_size: "18sp"
        size_hint_y: None
        height: dp(40)

    TextInput:
        id: code
        hint_text: "رمز الدخول"
        password: True
        multiline: False
        input_filter: "int"
        size_hint_y: None
        height: dp(52)
        on_text_validate: app.check_code()

    Button:
        text: "دخول"
        size_hint_y: None
        height: dp(52)
        on_release: app.check_code()

    Label:
        text: root.message
        text_size: self.width, None
        halign: "center"
        valign: "middle"
        size_hint_y: None
        height: dp(45)

    Widget:

<Root>:
    orientation: "vertical"
    padding: dp(16)
    spacing: dp(10)

    Label:
        text: "Telegram Backup"
        font_size: "24sp"
        size_hint_y: None
        height: dp(45)

    TextInput:
        id: token
        hint_text: "Bot Token"
        password: True
        multiline: False
        size_hint_y: None
        height: dp(48)

    TextInput:
        id: chat_id
        hint_text: "Chat ID"
        multiline: False
        size_hint_y: None
        height: dp(48)

    Button:
        text: "📸 إرسال جميع الصور"
        size_hint_y: None
        height: dp(52)
        on_release: app.confirm_all_images()

    Button:
        text: "📁 اختيار ملف وإرساله"
        size_hint_y: None
        height: dp(52)
        on_release: app.pick_file()

    Label:
        text: root.status
        text_size: self.width, None
        halign: "center"
        valign: "middle"

    ProgressBar:
        max: 1
        value: root.progress
        size_hint_y: None
        height: dp(12)
"""

class LockScreen(BoxLayout):
    message = StringProperty("")

class Root(BoxLayout):
    status = StringProperty("أدخل Bot Token و Chat ID ثم اختر العملية.")
    progress = NumericProperty(0)

class TelegramBackupApp(App):
    def build(self):
        Builder.load_string(KV)
        self.unlocked = False
        self.main_root = Root()
        self.lock_root = LockScreen()
        return self.lock_root

    def on_start(self):
        self.unlocked = False
        Clock.schedule_once(lambda *_: self.focus_lock_input(), 0.25)

    def on_resume(self):
        # Require the code again whenever the app UI is brought back to the foreground.
        if hasattr(self, "unlocked"):
            self.unlocked = False
            Clock.schedule_once(lambda *_: self.show_lock_screen(), 0)

    def show_lock_screen(self):
        self.unlocked = False
        self.lock_root.ids.code.text = ""
        self.lock_root.message = ""
        self.root = self.lock_root
        self.focus_lock_input()

    def focus_lock_input(self):
        try:
            self.lock_root.ids.code.focus = True
        except Exception:
            pass

    def check_code(self):
        code = self.lock_root.ids.code.text
        if code == APP_CODE:
            self.unlocked = True
            self.lock_root.message = ""
            self.root = self.main_root
            self.lock_root.ids.code.text = ""
        else:
            self.lock_root.message = "الرمز غير صحيح. حاول مرة أخرى."
            self.lock_root.ids.code.text = ""
            self.focus_lock_input()

    def set_status(self, text, progress=None):
        def update(_):
            self.main_root.status = text
            if progress is not None:
                self.main_root.progress = max(0, min(1, progress))
        Clock.schedule_once(update, 0)

    def credentials(self):
        token = self.main_root.ids.token.text.strip()
        chat_id = self.main_root.ids.chat_id.text.strip()
        if not token or not chat_id:
            self.set_status("أدخل Bot Token و Chat ID أولاً.")
            return None, None
        return token, chat_id

    def confirm_all_images(self):
        token, chat_id = self.credentials()
        if not token:
            return

        from kivy.uix.popup import Popup
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.label import Label
        from kivy.uix.button import Button

        box = BoxLayout(orientation="vertical", padding=16, spacing=10)
        box.add_widget(Label(
            text="سيتم إرسال الصور التي يستطيع التطبيق الوصول إليها إلى Chat ID المحدد. هل تريد المتابعة?"
        ))
        buttons = BoxLayout(size_hint_y=None, height=50, spacing=10)
        popup = Popup(title="تأكيد الإرسال", content=box, size_hint=(0.9, 0.5))
        yes = Button(text="موافق")
        no = Button(text="إلغاء")
        no.bind(on_release=popup.dismiss)
        yes.bind(on_release=lambda *_: (popup.dismiss(), self.start_all_images(token, chat_id)))
        buttons.add_widget(no)
        buttons.add_widget(yes)
        box.add_widget(buttons)
        popup.open()

    def start_all_images(self, token, chat_id):
        self.set_status("جاري تجهيز الصور...")
        threading.Thread(target=self._all_images_worker, args=(token, chat_id), daemon=True).start()

    def _all_images_worker(self, token, chat_id):
        try:
            paths = self.get_image_paths()
        except Exception as e:
            self.set_status(f"تعذر الوصول للصور: {e}")
            return

        if not paths:
            self.set_status("لم يتم العثور على صور يمكن للتطبيق الوصول إليها.")
            return

        total = len(paths)
        for i, path in enumerate(paths, 1):
            try:
                self.send_document(token, chat_id, path)
            except Exception as e:
                self.set_status(f"فشل عند الصورة {i}: {e}", (i-1)/total)
                return
            self.set_status(f"تم إرسال {i} من {total}", i/total)
            time.sleep(0.15)

        self.set_status(f"اكتمل الإرسال: {total} صورة.", 1)

    def get_image_paths(self):
        from android.permissions import request_permissions, Permission, check_permission

        # Android 13+ uses READ_MEDIA_IMAGES.
        # Android 12 and older use READ_EXTERNAL_STORAGE.
        if hasattr(Permission, "READ_MEDIA_IMAGES"):
            if not check_permission(Permission.READ_MEDIA_IMAGES):
                request_permissions([Permission.READ_MEDIA_IMAGES])
                time.sleep(2)
        elif hasattr(Permission, "READ_EXTERNAL_STORAGE"):
            if not check_permission(Permission.READ_EXTERNAL_STORAGE):
                request_permissions([Permission.READ_EXTERNAL_STORAGE])
                time.sleep(2)

        from jnius import autoclass
        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        activity = PythonActivity.mActivity
        resolver = activity.getContentResolver()

        Media = autoclass("android.provider.MediaStore$Images$Media")
        uri = Media.EXTERNAL_CONTENT_URI

        projection = [Media.DATA, Media.DISPLAY_NAME]
        cursor = resolver.query(uri, projection, None, None, Media.DATE_ADDED + " DESC")
        if cursor is None:
            return []

        result = []
        try:
            idx = cursor.getColumnIndex(Media.DATA)
            while cursor.moveToNext():
                p = cursor.getString(idx)
                if p and os.path.isfile(p):
                    result.append(p)
        finally:
            cursor.close()
        return result

    def pick_file(self):
        token, chat_id = self.credentials()
        if not token:
            return

        from kivy.uix.filechooser import FileChooserListView
        from kivy.uix.popup import Popup
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button

        chooser = FileChooserListView(path="/storage/emulated/0", filters=["*.*"])
        box = BoxLayout(orientation="vertical")
        box.add_widget(chooser)

        buttons = BoxLayout(size_hint_y=None, height=50)
        send = Button(text="إرسال")
        cancel = Button(text="إلغاء")
        buttons.add_widget(cancel)
        buttons.add_widget(send)
        box.add_widget(buttons)

        popup = Popup(title="اختر ملفًا", content=box, size_hint=(0.95, 0.85))
        cancel.bind(on_release=popup.dismiss)

        def do_send(*_):
            if not chooser.selection:
                return
            path = chooser.selection[0]
            popup.dismiss()
            threading.Thread(target=self._single_file_worker, args=(token, chat_id, path), daemon=True).start()

        send.bind(on_release=do_send)
        popup.open()

    def _single_file_worker(self, token, chat_id, path):
        try:
            self.set_status("جاري الإرسال...", 0)
            self.send_document(token, chat_id, path)
            self.set_status("تم إرسال الملف.", 1)
        except Exception as e:
            self.set_status(f"فشل الإرسال: {e}")

    def send_document(self, token, chat_id, path):
        url = f"https://api.telegram.org/bot{token}/sendDocument"
        filename = os.path.basename(path)
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        with open(path, "rb") as f:
            r = requests.post(url, data={"chat_id": chat_id},
                              files={"document": (filename, f, mime)}, timeout=120)
        if r.status_code != 200:
            try:
                msg = r.json().get("description", r.text)
            except Exception:
                msg = r.text
            raise RuntimeError(msg)

if __name__ == "__main__":
    TelegramBackupApp().run()
