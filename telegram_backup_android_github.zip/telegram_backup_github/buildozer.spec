[app]
title = Telegram Backup
package.name = telegrambackup
package.domain = org.example
source.dir = .
source.include_exts = py,kv,png,jpg,jpeg,txt
version = 0.2
requirements = python3,kivy,requests,pyjnius
orientation = portrait

# Android 13+ and Android 12-
android.permissions = INTERNET,READ_MEDIA_IMAGES,READ_EXTERNAL_STORAGE

[buildozer]
log_level = 2
warn_on_root = 1
